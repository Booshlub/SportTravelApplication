// JavaScript Document
(function() {
	"use strict";
	console.log("SEAF Fired");
		
	var button = document.querySelector("#button");
	
	function calcNum()
	{
		console.log("Entered Function!");
		var input = document.querySelector("#number");
		var numb = input.value;
		var answer = document.querySelector("#answer");
		
		var numberArray = numb.split("");

		var newAnswer = Number(numb)+1;
		var newAnswerArray = newAnswer.toString().split("");

		var length = newAnswerArray.length;

		var i;
		var k;

		//console.log(newAnswerArray[1]);

		//answer.innerHTML = strNumb;

		//console.log(splitNumbers);
		//console.log(newAnswerArray);

		function success(newAnswer){
			console.log('This is the result', newAnswer);
			answer.innerHTML = newAnswer;
		}

		for(i=0;i<length;i++){
			for(k=0;k<length;k++){
				console.log('this is i',i);
				console.log('this is newAnswerArray',newAnswerArray,newAnswerArray[i]);
				console.log('this is numberArray',numberArray,numberArray[k]);
				if(newAnswerArray[i] === numberArray[k]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;
				}else if(newAnswerArray[i] === numberArray[k+1]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;
				}else if(newAnswerArray[i] === numberArray[k+2]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;
				}else if(newAnswerArray[i] === numberArray[k+3]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else if(newAnswerArray[i] === numberArray[k+4]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else if(newAnswerArray[i] === numberArray[k+5]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else if(newAnswerArray[i] === numberArray[k+6]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else if(newAnswerArray[i] === numberArray[k+7]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else if(newAnswerArray[i] === numberArray[k+8]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else if(newAnswerArray[i] === numberArray[k+9]){
					var newAnswer = newAnswer+1;
					var newAnswerArray = newAnswer.toString().split("");i=-1;continue;
				}else{
					console.log('not equal!');
					success(newAnswer);
				}
			}
		
	}
	}
	
	button.addEventListener("click", calcNum, false);
	
})();